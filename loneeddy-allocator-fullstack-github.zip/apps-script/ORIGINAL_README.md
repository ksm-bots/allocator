# LoneEddy Allocator V7 — Fair + Right-3 + Right-2 Balance

This version keeps everything from V6 and adds another balance layer.

## 1. Exact Right-3 limit per seller

Example:
PT = Right-3 Limit 2
HOM = Right-3 Limit 1

For exact suffix 013:
216013
506013
556013
664013
703013
769013
981013

PT can get up to 2 tickets ending in 013 in one cycle.
HOM can get only 1 ticket ending in 013 in one cycle.

## 2. Right-3 bucket balance 0–9

Based on the hundreds digit of the last 3 digits:

000–099 = R3 bucket 0
100–199 = R3 bucket 1
...
900–999 = R3 bucket 9

Example:
976004 -> Right3=004 -> R3 bucket 0
814205 -> Right3=205 -> R3 bucket 2
965371 -> Right3=371 -> R3 bucket 3
941930 -> Right3=930 -> R3 bucket 9

## 3. NEW: Right-2 bucket balance 0–9

Based on the tens digit of the last 2 digits:

00–09 = R2 bucket 0
10–19 = R2 bucket 1
20–29 = R2 bucket 2
...
90–99 = R2 bucket 9

Example:
976004 -> Right2=04 -> R2 bucket 0
945016 -> Right2=16 -> R2 bucket 1
723017 -> Right2=17 -> R2 bucket 1
932031 -> Right2=31 -> R2 bucket 3
953094 -> Right2=94 -> R2 bucket 9

## How the allocator chooses a ticket

For every seller it checks:

1. Is the exact Right-3 suffix still allowed by that seller's Right-3 Limit?
2. Which Right-3 0–9 bucket currently has fewer tickets?
3. Which Right-2 0–9 bucket currently has fewer tickets?
4. Choose a ticket that improves BOTH balances as much as possible.

So if a seller has too many R3 0xx tickets but too few R3 7xx,
and also too few R2 4x tickets,
a 7xx ticket ending in 4x will be strongly preferred when available.

## Fair allocation

Sellers are still served round-by-round:

PT -> HOM -> MF440 -> MF70 -> MF50a -> PT -> ...

Unique tickets are used first.
Repeats happen only when unique stock is insufficient and Repeat is enabled.

## New summary sheet

The system creates:

RightBalanceSummary

It shows:

Seller
Quota
R3 Limit
R3 0xx ... R3 9xx
R3 Max-Min
R2 0x ... R2 9x
R2 Max-Min

A smaller Max-Min means the distribution is more balanced.

## Output sheets

- Distribution
- AssignedLog
- RightBalanceSummary

## Install

Replace BOTH:
- Code.gs
- index.html

Then redeploy Apps Script and put the new `/exec` URL into index.html.
