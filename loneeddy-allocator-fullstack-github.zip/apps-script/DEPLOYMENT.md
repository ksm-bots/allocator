# LoneEddy Allocator — Google Sheet handoff

This folder contains the Apps Script backend prepared for the spreadsheet:

`https://docs.google.com/spreadsheets/d/1EV8jc9Tb7E78HGcg7G3nRamrBNtaC1-wXoWuwJzWBUY/edit`

The script now uses `SpreadsheetApp.openById(...)`, so it does not depend on the account that created the Manus project. The account that deploys the script must have access to the target spreadsheet and must authorize the script when prompted.

## Deploy from the spreadsheet owner’s account

Open the target spreadsheet while signed in to the correct Google account. Use **Extensions → Apps Script**, replace the existing script with `Code.gs`, and save. Deploy it as a **Web app** with **Execute as: Me** and **Who has access: Anyone** or the narrowest audience that can reach the allocator. Copy the resulting `/exec` URL.

The website’s **Source & settings** panel accepts that `/exec` URL. After connecting, run a source refresh and confirm that the `Group` tab contains the allocator input in columns `A:J` with valid six-digit ticket values. The allocator writes to `Distribution`, `AssignedLog`, and `RightBalanceSummary`.

## Important safety notes

This handoff does not fabricate or seed ticket data. It only reads the existing `Group!A:J` values and creates or refreshes the output sheets when an allocation is run. Before deployment, confirm that the target spreadsheet owner is comfortable with the web-app access setting and the output-sheet behavior.
