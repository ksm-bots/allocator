
const CONFIG = {
  // Target spreadsheet supplied by the user. The deploying account must have access.
  SPREADSHEET_ID: '1EV8jc9Tb7E78HGcg7G3nRamrBNtaC1-wXoWuwJzWBUY',
  GROUP_SHEET: 'Group',
  RESULT_SHEET: 'Distribution',
  LOG_SHEET: 'AssignedLog',
  SUMMARY_SHEET: 'RightBalanceSummary',
  TIMEZONE: 'Asia/Yangon'
};

function doGet(e) {
  const p = (e && e.parameter) || {};
  const callback = safeCallback_(p.callback || 'callback');

  try {
    const action = String(p.action || 'status').toLowerCase();
    let result;

    if (action === 'status') {
      result = getStatus_();
    } else if (action === 'allocatebatch') {
      result = allocateBatch_({
        people: JSON.parse(p.people || '[]'),
        repeat: String(p.repeat || '1') !== '0',
        includeLeftover: String(p.includeLeftover || '1') !== '0',
        sheetName: String(p.sheetName || CONFIG.RESULT_SHEET).trim() || CONFIG.RESULT_SHEET
      });
    } else {
      throw new Error('Unknown action: ' + action);
    }

    return jsonp_(callback, {ok:true, ...result});
  } catch (err) {
    return jsonp_(callback, {
      ok:false,
      error: err && err.message ? err.message : String(err)
    });
  }
}

function readTickets_() {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  const sh = ss.getSheetByName(CONFIG.GROUP_SHEET);
  if (!sh) throw new Error('Sheet "' + CONFIG.GROUP_SHEET + '" was not found.');

  // Group ticket data is ONLY in columns A:J.
  // Do not use getLastColumn() here because other helper/formula columns on the
  // Group sheet can contain 6-digit values and were being counted as tickets.
  const lastRow = sh.getLastRow();
  const DATA_START_COL = 1; // A
  const DATA_COLS = 10;     // A:J only

  if (lastRow < 1) {
    return {tickets:[], duplicatesIgnored:0, invalidIgnored:0};
  }

  const values = sh.getRange(1, DATA_START_COL, lastRow, DATA_COLS).getDisplayValues();
  const tickets = [];
  const seen = new Set();
  let duplicatesIgnored = 0;
  let invalidIgnored = 0;

  for (let r=0; r<values.length; r++) {
    for (let c=0; c<values[r].length; c++) {
      let raw = String(values[r][c] || '').trim().replace(/\s+/g,'');
      if (!raw) continue;

      if (!/^\d{6}$/.test(raw)) {
        invalidIgnored++;
        continue;
      }

      if (seen.has(raw)) {
        duplicatesIgnored++;
        continue;
      }

      seen.add(raw);

      const right3 = raw.slice(-3);   // e.g. 004
      const right2 = raw.slice(-2);   // e.g. 04

      const r3Bucket = Number(right3.charAt(0)); // 0xx ... 9xx
      const r2Bucket = Number(right2.charAt(0)); // 0x ... 9x

      tickets.push({
        ticket: raw,
        right3,
        right2,
        r3Bucket,
        r2Bucket
      });
    }
  }

  return {tickets, duplicatesIgnored, invalidIgnored};
}

function getStatus_() {
  const data = readTickets_();

  const suffixCounts = {};
  const r3BucketCounts = Array(10).fill(0);
  const r2BucketCounts = Array(10).fill(0);
  let largest = 0;

  data.tickets.forEach(x => {
    suffixCounts[x.right3] = (suffixCounts[x.right3] || 0) + 1;
    largest = Math.max(largest, suffixCounts[x.right3]);
    r3BucketCounts[x.r3Bucket]++;
    r2BucketCounts[x.r2Bucket]++;
  });

  return {
    totalTickets: data.tickets.length,
    totalGroups: Object.keys(suffixCounts).length,
    largestGroup: largest,
    r3BucketCounts,
    r2BucketCounts,
    duplicatesIgnored: data.duplicatesIgnored,
    invalidIgnored: data.invalidIgnored,
    mode: 'FAIR_R3_R2_BALANCED',
    columns: []
  };
}

function allocateBatch_(opts) {
  if (!Array.isArray(opts.people) || !opts.people.length) {
    throw new Error('Add at least one seller.');
  }

  const people = opts.people.map((p, i) => {
    const name = String(p.name || '').trim();
    const qty = Math.floor(Number(p.qty || 0));
    const right3Limit = Math.max(
      0,
      Math.floor(Number(p.right3Limit || p.groupLimit || 0))
    );

    if (!name) throw new Error('Seller #' + (i + 1) + ' has no name.');
    if (!qty || qty < 1) throw new Error(name + ': quota must be at least 1.');

    return {
      name,
      qty,
      right3Limit,
      assigned: [],
      suffixCounts: {},
      r3BucketCounts: Array(10).fill(0),
      r2BucketCounts: Array(10).fill(0)
    };
  });

  const source = readTickets_();
  const tickets = source.tickets;

  if (!tickets.length) {
    throw new Error('No valid 6-digit lottery numbers found in sheet "Group".');
  }

  const totalDemand = people.reduce((n,p)=>n+p.qty,0);
  const globallyUsed = new Set();
  let totalAssigned = 0;

  // ---------------- UNIQUE FAIR ROUNDS ----------------
  let madeProgress = true;

  while (
    totalAssigned < totalDemand &&
    globallyUsed.size < tickets.length &&
    madeProgress
  ) {
    madeProgress = false;

    for (let i=0; i<people.length; i++) {
      const person = people[i];
      if (person.assigned.length >= person.qty) continue;

      const found = findBestTicket_(
        tickets,
        x => !globallyUsed.has(x.ticket),
        person
      );

      if (!found) continue;

      globallyUsed.add(found.ticket);
      applyTicketToPerson_(person, found, false, 1);
      totalAssigned++;
      madeProgress = true;

      if (totalAssigned >= totalDemand) break;
    }
  }

  const stillShort = people.filter(p => p.assigned.length < p.qty);

  if (stillShort.length && !opts.repeat) {
    throw new Error(
      'Cannot fill all quotas with unique tickets while respecting each seller Right-3 limit. ' +
      'Enable Repeat Tickets or increase a seller Right-3 limit.'
    );
  }

  // ---------------- REPEAT FAIR ROUNDS ----------------
  if (stillShort.length && opts.repeat) {
    const useCounts = new Map();
    tickets.forEach(x => {
      useCounts.set(x.ticket, globallyUsed.has(x.ticket) ? 1 : 0);
    });

    let safety = 0;
    const maxSafety = Math.max(100000, totalDemand * Math.max(20, tickets.length));

    while (people.some(p => p.assigned.length < p.qty)) {
      let progress = false;

      for (let i=0; i<people.length; i++) {
        const person = people[i];
        if (person.assigned.length >= person.qty) continue;

        let found = findBestTicket_(tickets, () => true, person);

        // If every exact Right-3 suffix is blocked by the seller's limit,
        // start a new exact-suffix cycle.
        // IMPORTANT: R3 bucket and R2 bucket counts are NOT reset,
        // so the overall 0-9 balance keeps improving.
        if (!found && person.right3Limit > 0) {
          person.suffixCounts = {};
          found = findBestTicket_(tickets, () => true, person);
        }

        if (!found) {
          throw new Error('No eligible ticket is available for ' + person.name + '.');
        }

        const old = useCounts.get(found.ticket) || 0;
        const next = old + 1;
        useCounts.set(found.ticket, next);

        applyTicketToPerson_(person, found, old > 0, next);
        totalAssigned++;
        progress = true;
        safety++;

        if (safety > maxSafety) {
          throw new Error('Allocation safety stop. Check quota and Right-3 limits.');
        }
      }

      if (!progress) break;
    }
  }

  people.forEach(p => {
    if (p.assigned.length !== p.qty) {
      throw new Error(
        p.name + ' received ' + p.assigned.length +
        ' of ' + p.qty + '. Increase Right-3 limit or enable repeats.'
      );
    }
  });

  const leftover = tickets.filter(x => !globallyUsed.has(x.ticket));

  const batchId =
    Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyyMMdd-HHmmss') +
    '-' + Math.random().toString(36).slice(2,7).toUpperCase();

  saveHorizontalResult_(
    opts.sheetName,
    batchId,
    people,
    opts.includeLeftover ? leftover : []
  );

  saveLog_(batchId, people);

  return {
    batchId,
    sheetName: opts.sheetName,
    totalRequested: totalDemand,
    totalUniqueStock: tickets.length,
    uniqueUsed: globallyUsed.size,
    repeatTotal: people.reduce(
      (n,p)=>n+p.assigned.filter(x=>x.isRepeat).length,0
    ),
    leftoverQty: leftover.length,
    duplicatesIgnored: source.duplicatesIgnored,
    invalidIgnored: source.invalidIgnored,
    mode: 'FAIR_R3_R2_BALANCED',
    people: people.map(p => ({
      name: p.name,
      qty: p.qty,
      right3Limit: p.right3Limit,
      assignedQty: p.assigned.length,
      uniqueQty: p.assigned.filter(x=>!x.isRepeat).length,
      repeatQty: p.assigned.filter(x=>x.isRepeat).length,
      r3BucketCounts: p.r3BucketCounts,
      r2BucketCounts: p.r2BucketCounts,
      preview: p.assigned.slice(0,100).map(x=>x.ticket)
    }))
  };
}

/**
 * Select the ticket that best improves BOTH:
 *   Right-3 buckets: 0xx,1xx,...9xx
 *   Right-2 buckets: 0x,1x,...9x
 *
 * Priority:
 * 1. Respect exact Right-3 limit.
 * 2. Prefer the ticket whose two buckets are currently least filled.
 * 3. Prefer lower exact-right3 repetition.
 */
function findBestTicket_(tickets, allowedFn, person) {
  let best = null;
  let bestMaxBucket = Infinity;
  let bestSumBucket = Infinity;
  let bestR3Bucket = Infinity;
  let bestR2Bucket = Infinity;
  let bestExactSuffix = Infinity;

  for (let i=0; i<tickets.length; i++) {
    const x = tickets[i];

    if (!allowedFn(x)) continue;

    const exactCount = person.suffixCounts[x.right3] || 0;
    if (person.right3Limit > 0 && exactCount >= person.right3Limit) continue;

    const r3Count = person.r3BucketCounts[x.r3Bucket] || 0;
    const r2Count = person.r2BucketCounts[x.r2Bucket] || 0;

    const maxBucket = Math.max(r3Count, r2Count);
    const sumBucket = r3Count + r2Count;

    const better =
      maxBucket < bestMaxBucket ||
      (
        maxBucket === bestMaxBucket &&
        sumBucket < bestSumBucket
      ) ||
      (
        maxBucket === bestMaxBucket &&
        sumBucket === bestSumBucket &&
        r3Count < bestR3Bucket
      ) ||
      (
        maxBucket === bestMaxBucket &&
        sumBucket === bestSumBucket &&
        r3Count === bestR3Bucket &&
        r2Count < bestR2Bucket
      ) ||
      (
        maxBucket === bestMaxBucket &&
        sumBucket === bestSumBucket &&
        r3Count === bestR3Bucket &&
        r2Count === bestR2Bucket &&
        exactCount < bestExactSuffix
      );

    if (better) {
      best = x;
      bestMaxBucket = maxBucket;
      bestSumBucket = sumBucket;
      bestR3Bucket = r3Count;
      bestR2Bucket = r2Count;
      bestExactSuffix = exactCount;
    }
  }

  return best;
}

function applyTicketToPerson_(person, x, isRepeat, repeatNo) {
  person.suffixCounts[x.right3] =
    (person.suffixCounts[x.right3] || 0) + 1;

  person.r3BucketCounts[x.r3Bucket]++;
  person.r2BucketCounts[x.r2Bucket]++;

  person.assigned.push({
    ticket: x.ticket,
    right3: x.right3,
    right2: x.right2,
    r3Bucket: x.r3Bucket,
    r2Bucket: x.r2Bucket,
    isRepeat,
    repeatNo
  });
}

function saveHorizontalResult_(sheetName, batchId, people, leftover) {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  let sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);

  sh.clearContents();
  sh.clearFormats();

  const columns = people.map(p => ({
    header:
      p.name + ' (' + p.qty + ')' +
      (p.right3Limit ? ' R3×' + p.right3Limit : ''),
    values: p.assigned.map(x=>x.ticket)
  }));

  if (leftover && leftover.length) {
    columns.push({
      header: 'Leftover (' + leftover.length + ')',
      values: leftover.map(x=>x.ticket)
    });
  }

  const maxRows = Math.max(0, ...columns.map(c=>c.values.length));
  const data = [columns.map(c=>c.header)];

  for (let r=0; r<maxRows; r++) {
    data.push(columns.map(c => c.values[r] ? "'" + c.values[r] : ''));
  }

  if (columns.length) {
    sh.getRange(1,1,data.length,columns.length).setValues(data);
    sh.setFrozenRows(1);

    sh.getRange(1,1,1,columns.length)
      .setFontWeight('bold')
      .setHorizontalAlignment('center')
      .setBackground('#d9eaf7');

    if (maxRows > 0) {
      sh.getRange(2,1,maxRows,columns.length)
        .setNumberFormat('@')
        .setHorizontalAlignment('center');
    }

    for (let c=1; c<=columns.length; c++) {
      sh.setColumnWidth(c,120);
    }

    sh.getRange('A1').setNote(
      'Batch ID: ' + batchId +
      '\nMode: FAIR + EXACT RIGHT3 LIMIT + BALANCED RIGHT3 0-9 + BALANCED RIGHT2 0-9'
    );
  }

  saveBalanceSummary_(ss, people, batchId);
}

function saveBalanceSummary_(ss, people, batchId) {
  let sh = ss.getSheetByName(CONFIG.SUMMARY_SHEET);
  if (!sh) sh = ss.insertSheet(CONFIG.SUMMARY_SHEET);

  sh.clearContents();
  sh.clearFormats();

  const headers = [
    'Seller','Quota','R3 Limit',
    'R3 0xx','R3 1xx','R3 2xx','R3 3xx','R3 4xx',
    'R3 5xx','R3 6xx','R3 7xx','R3 8xx','R3 9xx','R3 Max-Min',
    'R2 0x','R2 1x','R2 2x','R2 3x','R2 4x',
    'R2 5x','R2 6x','R2 7x','R2 8x','R2 9x','R2 Max-Min'
  ];

  const rows = [headers];

  people.forEach(p => {
    const r3Max = Math.max(...p.r3BucketCounts);
    const r3Min = Math.min(...p.r3BucketCounts);
    const r2Max = Math.max(...p.r2BucketCounts);
    const r2Min = Math.min(...p.r2BucketCounts);

    rows.push([
      p.name,
      p.qty,
      p.right3Limit || 'AUTO',
      ...p.r3BucketCounts,
      r3Max-r3Min,
      ...p.r2BucketCounts,
      r2Max-r2Min
    ]);
  });

  sh.getRange(1,1,rows.length,headers.length).setValues(rows);
  sh.setFrozenRows(1);

  sh.getRange(1,1,1,headers.length)
    .setFontWeight('bold')
    .setBackground('#e7f0ff');

  sh.getRange(1,1,rows.length,headers.length)
    .setHorizontalAlignment('center');

  sh.getRange('A1').setNote('Batch ID: ' + batchId);

  for (let c=1; c<=headers.length; c++) {
    sh.autoResizeColumn(c);
  }
}

function saveLog_(batchId, people) {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  let sh = ss.getSheetByName(CONFIG.LOG_SHEET);
  if (!sh) sh = ss.insertSheet(CONFIG.LOG_SHEET);

  const headers = [
    'Timestamp','Batch ID','Seller','Requested Qty','Right3 Limit',
    'Sequence','Ticket Number','Right 3','Right 2',
    'R3 Bucket','R2 Bucket','Is Repeat','Repeat No'
  ];

  if (sh.getLastRow() === 0) {
    sh.getRange(1,1,1,headers.length).setValues([headers]);
    sh.setFrozenRows(1);
  }

  const now = Utilities.formatDate(
    new Date(),
    CONFIG.TIMEZONE,
    'dd-MM-yyyy HH:mm:ss'
  );

  const rows = [];

  people.forEach(p => {
    p.assigned.forEach((x,i) => {
      rows.push([
        now,
        batchId,
        p.name,
        p.qty,
        p.right3Limit || 'AUTO',
        i+1,
        "'" + x.ticket,
        x.right3,
        x.right2,
        x.r3Bucket,
        x.r2Bucket,
        x.isRepeat ? 'YES' : 'NO',
        x.repeatNo
      ]);
    });
  });

  if (rows.length) {
    sh.getRange(
      sh.getLastRow()+1,
      1,
      rows.length,
      headers.length
    ).setValues(rows);
  }
}

function jsonp_(callback,obj) {
  return ContentService
    .createTextOutput(callback + '(' + JSON.stringify(obj) + ');')
    .setMimeType(ContentService.MimeType.JAVASCRIPT);
}

function safeCallback_(name) {
  name = String(name || 'callback');
  return /^[A-Za-z_$][0-9A-Za-z_$\.]*$/.test(name) ? name : 'callback';
}
